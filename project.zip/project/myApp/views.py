from django.shortcuts import render
from django.http import HttpResponse
from .models import Employee
from datetime import datetime
from django.db.models import Q
from .project2 import *


data = [
    {
        "id": "ffb87ea3",
        "name": "Jeffrey Walker",
        "dob": "23-02-2014",
        "address": "Sherrifort",
        "email": "ashleyterrell@example.net",
        "position": "Camera operator",
        "salary": 44752000,
    },
    {
        "id": "ce72c9e2",
        "name": "Mary Price",
        "dob": "22-12-1967",
        "address": "South Rachel",
        "email": "desiree66@example.net",
        "position": "Advertising account planner",
        "salary": 73751000,
    },
    {
        "id": "5854eab6",
        "name": "Hunter Mckay",
        "dob": "30-07-1932",
        "address": "Port Alex",
        "email": "vhall@example.com",
        "position": "Scientist, marine",
        "salary": 81282000,
    },
    {
        "id": "57ac5317",
        "name": "Robert Dean",
        "dob": "29-03-2024",
        "address": "Spearstown",
        "email": "gcarter@example.net",
        "position": "Geologist, wellsite",
        "salary": 64250000,
    },
    {
        "id": "2b359f74",
        "name": "Allison Daugherty",
        "dob": "22-08-1970",
        "address": "Deborahbury",
        "email": "kmccarthy@example.org",
        "position": "Insurance underwriter",
        "salary": 55500000,
    },
    {
        "id": "4ccc0b0f",
        "name": "Jacqueline Patel",
        "dob": "16-12-2020",
        "address": "Lake Mary",
        "email": "zrogers@example.net",
        "position": "Medical sales representative",
        "salary": 34484000,
    },
    {
        "id": "6d0dfc35",
        "name": "Steven Parker",
        "dob": "02-02-1939",
        "address": "Sampsonview",
        "email": "jasminehowell@example.net",
        "position": "Accountant, chartered public finance",
        "salary": 81956000,
    },
    {
        "id": "e8911024",
        "name": "Denise Patel",
        "dob": "11-11-1974",
        "address": "Elizabethhaven",
        "email": "lindalee@example.com",
        "position": "Higher education lecturer",
        "salary": 66120000,
    },
    {
        "id": "f452a1d5",
        "name": "Eric Alvarez",
        "dob": "07-04-1996",
        "address": "Port Candace",
        "email": "youngsamantha@example.org",
        "position": "Building control surveyor",
        "salary": 74238000,
    },
    {
        "id": "14a1d631",
        "name": "Megan Vance",
        "dob": "06-05-1932",
        "address": "West Cherylview",
        "email": "jacquelinewilliams@example.com",
        "position": "Doctor, general practice",
        "salary": 45588000,
    },
]


EMP_DATA = BTree(3)
i = 0
for row in data:
    x = str("0" * (6 - len(str(i))) + str(i))
    EMP_DATA.insert(x, row)
    i += 1


def random(request):
    return render(request, "index.html")


def all_emp(request):
    context = {}
    emps = EMP_DATA.inorder_traversal()
    context = {"emps": emps}
    return render(request, "all_emp.html", context)


def add_emp(request):
    employee_added = False
    if request.method == "POST":
        ID1 = request.POST["id"]
        first_name = request.POST["first_name"]
        salary = request.POST["salary"]
        Birthday = request.POST["birthday"]
        Position = request.POST["position"]
        Email = request.POST["email"]
        Address = request.POST["address"]

        employee = {
            "id": str(ID1),
            "name": first_name,
            "salary": salary,
            "dob": Birthday,
            "position": Position,
            "email": Email,
            "address": Address,
        }
        EMP_DATA.insert(ID1, employee)
        emps = EMP_DATA.inorder_traversal()
        context = {"emps": emps}
        return render(request, "all_emp.html", context)

    elif request.method == "GET":
        employee_added = False
        return render(request, "add_emp.html")
    else:
        return HttpResponse("An Exception ocurred")


def remove_emp(request):
    if request.method == "POST":
        ID1 = str(request.POST["id"])
        EMP_DATA.delete(EMP_DATA.root, ID1)

        emps = EMP_DATA.inorder_traversal()
        context = {"emps": emps}
        return render(request, "all_emp.html", context)

    elif request.method == "GET":
        return render(request, "remove_emp.html")
    else:
        return HttpResponse("An Exception occurred")


def change_emp(request):
    if request.method == "POST":
        ID1 = request.POST["id"]
        emps = EMP_DATA.search(ID1)
        if emps == None:
            emps = [
                (
                    "",
                    {
                        "id": "",
                        "name": "",
                        "dob": "",
                        "address": "",
                        "email": "",
                        "position": "",
                        "salary": "",
                    },
                )
            ]
        else:
            emps = [(ID1, emps[1])]
        context = {"emps": emps}
        return render(request, "all_emp.html", context)
    elif request.method == "GET":
        return render(request, "change_emp.html")

    else:
        return HttpResponse("Error")


def update_emp(request):
    if request.method == "POST":
        ID1 = request.POST["id"]
        datatype = request.POST["datatype"]
        data = request.POST["data"]
        emps = EMP_DATA.search(ID1)
        print(emps)
        if emps is not None:
            emps[1][datatype] = data
            # if datatype == "name":
            #     emps[1]["name"] = data
            # elif datatype == "dob":
            #     emps[1]["dob"] = data
            # elif datatype == "address":
            #     emps[1]["address"] = data
            # elif datatype == "email":
            #     emps[1]["email"] = data
            # elif datatype == "position":
            #     emps[1]["position"] = data
            # elif datatype == "salary":
            #     emps[1]["salary"] = data

            EMP_DATA.update(ID1, emps[1])
            emps = EMP_DATA.search(ID1)
            context = {"emps": [emps]}
            print("emps\n")
            print(emps)
            return render(request, "all_emp.html", context)

    elif request.method == "GET":
        return render(request, "update_emp.html")
    else:
        return HttpResponse("Error")

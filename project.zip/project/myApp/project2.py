class Node:
    def __init__(self, leaf=False):
        self.keys = []
        self.data = []  # New: To store associated data
        self.children = []
        self.leaf = leaf


class BTree:
    def __init__(self, t):
        self.root = Node(True)
        self.t = t

    def search(self, key, node=None):
        node = self.root if node == None else node
    
        i = 0
        while i < len(node.keys) and key > node.keys[i]:
            i += 1
        if i < len(node.keys) and key == node.keys[i]:
            return (key , node.data[i])
        elif node.leaf:
            return None
        else:
            return self.search(key, node.children[i])

    def split_child(self, x, i):
        t = self.t
        y = x.children[i]
        
        z = Node(y.leaf)
        x.children.insert(i + 1, z)

        x.keys.insert(i, y.keys[t - 1])
        x.data.insert(i, y.data[t - 1])  # Modified: Insert associated data

        z.keys = y.keys[t: (2 * t) - 1]
        z.data = y.data[t: (2 * t) - 1]  # Modified: Split associated data
        y.keys = y.keys[0: t - 1]
        y.data = y.data[0: t - 1]  # Modified: Update associated data

        if not y.leaf:
            z.children = y.children[t: 2 * t]
            y.children = y.children[0: t - 1]

    def insert(self, key, data):  # Modified: Insert key and associated data
        t = self.t
        root = self.root

        if len(root.keys) == (2 * t) - 1:
            new_root = Node()
            self.root = new_root
            new_root.children.insert(0, root)
            self.split_child(new_root, 0)
            self.insert_non_full(new_root, key, data)
        else:
            self.insert_non_full(root, key, data)

    def insert_non_full(self, x, key, data):  # Modified: Insert key and associated data
        t = self.t
        i = len(x.keys) - 1

        if x.leaf:
            x.keys.append(None)
            x.data.append(None)
            while i >= 0 and key < x.keys[i]:
                x.keys[i + 1] = x.keys[i]
                x.data[i + 1] = x.data[i]
                i -= 1
            x.keys[i + 1] = key
            x.data[i + 1] = data
        else:
            while i >= 0 and key < x.keys[i]:
                i -= 1
            i += 1
            if len(x.children[i].keys) == (2 * t) - 1:
                self.split_child(x, i)
                if key > x.keys[i]:
                    i += 1
            self.insert_non_full(x.children[i], key, data)

    def delete(self, x, k):
        t = self.t
        i = 0

        while i < len(x.keys) and k > x.keys[i]:
            i += 1
        if x.leaf:
            if i < len(x.keys) and x.keys[i] == k:
                x.keys.pop(i)
            return

        if i < len(x.keys) and x.keys[i] == k:
            return self.delete_internal_node(x, k, i)
        elif len(x.children[i].keys) >= t:
            self.delete(x.children[i], k)
        else:
            if i != 0 and i + 2 < len(x.children):
                if len(x.children[i - 1].keys) >= t:
                    self.delete_sibling(x, i, i - 1)
                elif len(x.children[i + 1].keys) >= t:
                    self.delete_sibling(x, i, i + 1)
                else:
                    self.delete_merge(x, i, i + 1)
            elif i == 0:
                if len(x.children[i + 1].keys) >= t:
                    self.delete_sibling(x, i, i + 1)
                else:
                    self.delete_merge(x, i, i + 1)
            elif i + 1 == len(x.children):
                if len(x.children[i - 1].keys) >= t:
                    self.delete_sibling(x, i, i - 1)
                else:
                    self.delete_merge(x, i, i - 1)
            self.delete(x.children[i], k)

    def delete_internal_node(self, x, k, i):
        t = self.t
        if x.leaf:
            if x.keys[i] == k:
                x.keys.pop(i)
            return

        if len(x.children[i].keys) >= t:
            x.keys[i] = self.delete_predecessor(x.children[i])
            return
        elif len(x.children[i + 1].keys) >= t:
            x.keys[i] = self.delete_successor(x.children[i + 1])
            return
        else:
            self.delete_merge(x, i, i + 1)
            self.delete_internal_node(x.children[i], k, self.t - 1)

    def delete_predecessor(self, x):
        if x.leaf:
            return x.keys.pop()
        n = len(x.keys) - 1
        if len(x.children[n].keys) >= self.t:
            self.delete_sibling(x, n + 1, n)
        else:
            self.delete_merge(x, n, n + 1)
        self.delete_predecessor(x.children[n])

    def delete_successor(self, x):
        if x.leaf:
            return x.keys.pop(0)
        if len(x.children[1].keys) >= self.t:
            self.delete_sibling(x, 0, 1)
        else:
            self.delete_merge(x, 0, 1)
        self.delete_successor(x.children[0])

    def delete_merge(self, x, i, j):
        cnode = x.children[i]

        if j > i:
            rsnode = x.children[j]
            cnode.keys.append(x.keys[i])
            for k in range(len(rsnode.keys)):
                cnode.keys.append(rsnode.keys[k])
                if len(rsnode.children) > 0:
                    cnode.children.append(rsnode.children[k])
            if len(rsnode.children) > 0:
                cnode.children.append(rsnode.children.pop())
            new = cnode
            x.keys.pop(i)
            x.children.pop(j)
        else:
            lsnode = x.children[j]
            lsnode.keys.append(x.keys[j])
            for i in range(len(cnode.keys)):
                lsnode.keys.append(cnode.keys[i])
                if len(lsnode.children) > 0:
                    lsnode.children.append(cnode.children[i])
            if len(lsnode.children) > 0:
                lsnode.children.append(cnode.children.pop())
            new = lsnode
            x.keys.pop(j)
            x.children.pop(i)

        if x == self.root and len(x.keys) == 0:
            self.root = new

    def delete_sibling(self, x, i, j):
        cnode = x.children[i]
        if i < j:
            rsnode = x.children[j]
            cnode.keys.append(x.keys[i])
            x.keys[i] = rsnode.keys[0]
            if len(rsnode.children) > 0:
                cnode.children.append(rsnode.children[0])
                rsnode.children.pop(0)
            rsnode.keys.pop(0)
        else:
            lsnode = x.children[j]
            cnode.keys.insert(0, x.keys[i - 1])
            x.keys[i - 1] = lsnode.keys.pop()
            if len(lsnode.children) > 0:
                cnode.children.insert(0, lsnode.children.pop())

    def print_tree(self, x, level=0):
        print(f'Level {level}', end=": ")
        for i in range(len(x.keys)):  # Modified: Iterate over index range
            print((x.keys[i], x.data[i]), end=" ")  # Modified: Print key-data pairs
        print()
        level += 1
        if len(x.children) > 0:
            for i in x.children:
                self.print_tree(i, level)

    def inorder_traversal(self, x=None, visited=None):
        if x is None:
            x = self.root
            
        if visited is None:
            visited = set()

        result = []
        if not x.leaf:
            for i in range(len(x.children)):
                result += self.inorder_traversal(x.children[i], visited)
                if i < len(x.keys):
                    if x.keys[i] not in visited:
                        result.append((x.keys[i], x.data[i]))
                        visited.add(x.keys[i])
        else:
            for i in range(len(x.keys)):
                if x.keys[i] not in visited:
                    result.append((x.keys[i], x.data[i]))
                    visited.add(x.keys[i])

        return result
    
    def update(self, key, new_data):
        t = self.t
        x = self.root

        while True:
            i = 0
            while i < len(x.keys) and key > x.keys[i]:
                i += 1

            if i < len(x.keys) and key == x.keys[i]:
                x.data[i] = new_data
                return

            if x.leaf:
                break

            x = x.children[i]

        if t <= len(x.keys) < 2 * t:
            i = len(x.keys) - 1
            while i >= 0 and key > x.keys[i]:
                x.keys[i + 1] = x.keys[i]
                x.data[i + 1] = x.data[i]
                i -= 1
            x.keys[i + 1] = key
            x.data[i + 1] = new_data

        else:
            self.split_child(x, i + 1)
            if key > x.keys[i + 1]:
                i += 1
            self.update(key, new_data)


EMP_DATA = BTree(3)
    
def insert_and_search_example():
    
    i = 0
    with open('myApp\input.txt', 'r') as file:
        for line in file:
            data = eval(line.strip())  # Read each line as a dictionary
            x = str("0"*(6-len(str(i))) + str(i))
            EMP_DATA.insert(x, data)
            i += 1
    EMP_DATA.update('000000', {'id': 'eeb87ea3', 'name': 'Jeffrey Walker',
                               'dob': '23-02-2014', 'address': 'Sherrifort', 
                               'email': 'ashleyterrell@example.net', 
                               'position': 'Camera operator', 'salary': 44752000})        
    print(EMP_DATA.print_tree(EMP_DATA.root))
    # print()
    
    
    # for i in range(10):
    #     B.insert(i)

    # B.print_tree(B.root)
    # print()

    # keys_to_search_for = ["000002", "000004", "000009" , "000011" ]
    # for key in keys_to_search_for:
    #     if EMP_DATA.search(key) is not None:
    #         print(f'{key} is in the tree')
    #     else:
    #         print(f'{key} is NOT in the tree')
            
    # print(B.inorder_traversal())        

# def delete():
#     B = BTree(3)

#     # Inserting data into the B-tree
#     with open('input.txt', 'r') as file:
#         i = 0
#         for line in file:
#             data = eval(line.strip())  # Read each line as a dictionary
#             B.insert(i, data)
#             i += 1
    
#     # Print the B-tree before deletion
#     print("B-tree before deletion:")
#     B.print_tree(B.root)
#     print()
    
#     # Delete key 8
#     key_to_delete = 8
#     print(f"Deleting key {key_to_delete} from the B-tree...")
#     B.delete(B.root, key_to_delete)
    
#     # Print the B-tree after deletion
#     print("\nB-tree after deleting key 8:")
#     B.print_tree(B.root)
#     print()
    
#     # Delete key 5
#     key_to_delete = 5
#     print(f"Deleting key {key_to_delete} from the B-tree...")
#     B.delete(B.root, key_to_delete)
    
#     # Print the B-tree after deletion
#     print("\nB-tree after deleting key 5:")
#     B.print_tree(B.root)
#     print()




def main():
    print('\n--- INSERT & SEARCH ---\n')
    insert_and_search_example()
    # delete()
# 

main()


